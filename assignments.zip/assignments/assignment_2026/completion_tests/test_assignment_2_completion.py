"""Completion tests for Assignment 2.

These tests are intentionally separate from `tests/` so starter scaffolds can run
smoke tests before students implement the models. Run these after Assignment 2:

    python -m pytest completion_tests/test_assignment_2_completion.py
"""

import torch

from eo_models.cnn import SmallEOClassifier
from eo_models.losses import get_classification_loss, get_segmentation_loss
from eo_models.unet import SmallUNet
from eo_train.train import train_classification_one_epoch, validate_segmentation_one_epoch


def test_classifier_output_shape_after_implementation():
    model = SmallEOClassifier(in_channels=13, num_classes=10)
    x = torch.zeros((2, 13, 64, 64), dtype=torch.float32)
    y = model(x)
    assert y.shape == (2, 10)


def test_unet_output_shape_after_implementation():
    model = SmallUNet(in_channels=4, out_channels=1)
    x = torch.zeros((2, 4, 64, 64), dtype=torch.float32)
    y = model(x)
    assert y.shape[-2:] == x.shape[-2:]
    assert y.shape[0] == 2
    assert y.shape[1] == 1


def test_loss_helpers_return_usable_losses():
    class_logits = torch.zeros((2, 10))
    labels = torch.tensor([0, 1], dtype=torch.long)
    seg_logits = torch.zeros((2, 1, 16, 16))
    masks = torch.zeros((2, 1, 16, 16))
    assert torch.isfinite(get_classification_loss()(class_logits, labels))
    assert torch.isfinite(get_segmentation_loss()(seg_logits, masks))


def test_training_loop_returns_metrics():
    model = SmallEOClassifier(in_channels=13, num_classes=10, hidden_channels=4)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    batch = (torch.zeros((2, 13, 16, 16)), torch.tensor([0, 1], dtype=torch.long))
    metrics = train_classification_one_epoch(model, [batch], optimizer, get_classification_loss(), torch.device("cpu"))
    assert "loss" in metrics
    assert "accuracy" in metrics


def test_segmentation_validation_loop_returns_loss():
    model = SmallUNet(in_channels=4, out_channels=1, base_channels=4)
    batch = (torch.zeros((2, 4, 16, 16)), torch.zeros((2, 16, 16), dtype=torch.long))
    metrics = validate_segmentation_one_epoch(model, [batch], get_segmentation_loss(), torch.device("cpu"))
    assert "loss" in metrics
