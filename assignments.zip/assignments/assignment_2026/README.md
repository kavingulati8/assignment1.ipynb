# IDLEO Modular Assignments Project

This project contains scaffolded notebooks and source files for Assignments 1, 2, and 3. The notebooks run workflows, inspect outputs, and answer questions. Reusable code belongs in `src/`.

## Assignments

- `notebooks/assignment_1_data_loading.ipynb`: EuroSAT100 classification loading plus Planet catalog segmentation loading
- `notebooks/assignment_2_model_training.ipynb`: classifier training, U-Net-style segmentation training, losses, checkpoints, and model diagrams
- `notebooks/assignment_3_inference_evaluation.ipynb`: checkpoint loading, inference, segmentation evaluation, prediction visualization, and limitations

## Setup

### Colab quick start

1. Open a notebook in Colab.
2. Run the first `Colab/local setup` cell before any other code.
3. If the setup cell cannot find the project, clone or upload the repo, then run:

```python
%cd /content/idleo/assignments/assignment_2026
```

Assignment 1 downloads EuroSAT100 through TorchGeo with `download=True`. The Planet data helper cell also tries a best-effort `gdown` folder download from the course Google Drive link. If Google Drive blocks the automatic download because of quota or permissions, manually add/download the Drive folder and place `mappingafrica-256/` under `data/raw/`.

From this folder:

### Recommended local setup with uv

The Windows `python` command on some lab machines may point to another program, such as QGIS. Use `uv` when you want a clean assignment environment:

```powershell
uv venv .venv
.venv\Scripts\python -m pip install -e .
.venv\Scripts\python -m pytest tests
```

Verify imports:

```powershell
.venv\Scripts\python -c "import eo_dataloader, eo_models, eo_train, torch, torchgeo, rasterio; print('setup ok')"
```

### Alternative pip setup

```powershell
python -m pip install -r requirements.txt
python -m pip install -e .
python -m pytest tests
```

If your Python environment cannot import the local package, run notebooks from this folder or install the package with `python -m pip install -e .`. In Colab, upload or clone the assignment folder, install the requirements, and run the same editable install command.

Torch, TorchGeo, and rasterio can vary across local machines. Colab is usually the simplest path for GPU-backed training. Local Windows setups may require installing rasterio from a conda environment if `pip` wheels fail.

The `tests/` folder contains starter smoke tests. The `completion_tests/` folder contains stricter checks for the provided core implementation and final student submissions.

## Data

This scaffold uses two data sources.

1. EuroSAT100 is loaded through TorchGeo in Assignment 1. It is a packaged EO classification dataset and replaces the older MNIST starter task.
2. Planet image chips and masks use the provided `assignments/catalog.csv` file and the Planet data folder from Google Drive:
   <https://drive.google.com/drive/folders/11sdCgNpLtAy9YZrDCCGsNqglRX-mwV0f?usp=drive_link>

Download or copy the Planet data so the extracted `mappingafrica-256/` folder sits under:

```text
assignments/assignment_2026/data/raw/mappingafrica-256/
```

The canonical catalog is:

```text
assignments/catalog.csv
```

The important catalog columns are:

- `window_b`: relative image-chip path
- `mask`: relative mask path
- `split`: `train`, `validate`, or `test`
- `fld_prop`, `nonfld_prop`, `null_prop`: class-balance summaries
- `country`, `x`, `y`: spatial metadata

The assignment code resolves `window_b` and `mask` against `data/raw/`, so a row such as `mappingafrica-256/images/AO0632385_2022-11.tif` should point to `data/raw/mappingafrica-256/images/AO0632385_2022-11.tif`.

To work with a small local sample first, instantiate the dataset with `max_items=8` after downloading at least a few matching image/mask files.

## Before You Submit

- Run the setup cell in each notebook and confirm imports succeed.
- Run the provided smoke tests when possible: `python -m pytest tests`.
- Verify image, label, mask, and model-output shapes before training or evaluation.
- Save required outputs in `outputs/`, but do not submit raw data, virtual environments, caches, or model checkpoints unless explicitly requested.
- Complete `AI_USE.md` if you used an AI coding assistant.
- Re-run the notebook from a fresh runtime when possible so hidden state does not mask missing steps.

## Troubleshooting

- **Google Drive folder download fails:** use the manual fallback and copy `mappingafrica-256/` under `data/raw/`.
- **`catalog.csv` is missing:** keep the provided `assignments/catalog.csv` next to the `assignment_2026/` folder, or copy it into `assignment_2026/`.
- **`rasterio` installs slowly:** wait for Colab to finish the binary wheel install; local Windows installs can be more fragile than Colab.
- **No Planet data yet:** EuroSAT100 cells and catalog inspection can still run. Planet image-mask loading requires matching files.
- **No GPU:** Assignment 1 does not require a GPU. For Assignments 2 and 3, use small `max_items` values first if training is slow.

## Source Package

- `src/eo_dataloader/`: datasets, checks, visualization, utility functions
- `src/eo_models/`: model definitions and losses; the provided U-Net baseline is binary, so masks are interpreted as foreground (`mask > 0`) versus background during baseline training
- `src/eo_train/`: training, evaluation, inference, metrics, checkpoints

## Coding Assistance

Coding assistance is allowed. If used, complete `AI_USE.md` and verify generated code using the required checks. You remain responsible for understanding, testing, and explaining the code.

## Development Rule

Use snake case for file names, variable names, and function names. Python classes may use PascalCase.
