"""Lightweight tests for Assignment 1 helper functions."""

import torch
import pandas as pd
import rasterio
from rasterio.transform import from_origin

from eo_dataloader.checks import (
    check_catalog_schema,
    check_paths_exist,
    inspect_classification_batch,
    inspect_image_mask_batch,
    summarize_catalog_splits,
)
from eo_dataloader.datasets import PlanetCSVImageMaskDataset, load_image_mask_pair


def test_inspect_classification_batch_keys():
    images = torch.zeros((2, 13, 64, 64), dtype=torch.float32)
    labels = torch.tensor([0, 1], dtype=torch.long)
    results = inspect_classification_batch(images, labels)
    assert results["image_shape"] == (2, 13, 64, 64)
    assert results["label_shape"] == (2,)
    assert results["image_is_finite"] is True


def test_inspect_image_mask_batch_spatial_match():
    images = torch.zeros((2, 4, 32, 32), dtype=torch.float32)
    masks = torch.zeros((2, 32, 32), dtype=torch.long)
    results = inspect_image_mask_batch(images, masks)
    assert results["spatial_shapes_match"] is True


def test_catalog_schema_and_split_counts():
    df = pd.DataFrame(
        {
            "window_b": ["mappingafrica-256/images/a.tif", "mappingafrica-256/images/b.tif"],
            "mask": ["mappingafrica-256/labels/a.tif", "mappingafrica-256/labels/b.tif"],
            "split": ["train", "validate"],
            "fld_prop": [0.2, 0.4],
            "nonfld_prop": [0.8, 0.6],
            "null_prop": [0.0, 0.0],
            "country": ["AO", "ZW"],
        }
    )
    assert check_catalog_schema(df)["required_columns_present"] is True
    assert summarize_catalog_splits(df)["split_counts"] == {"train": 1, "validate": 1}


def test_catalog_paths_resolve_against_data_root(tmp_path):
    data_root = tmp_path / "raw"
    image_path = data_root / "mappingafrica-256" / "images" / "a.tif"
    mask_path = data_root / "mappingafrica-256" / "labels" / "a.tif"
    image_path.parent.mkdir(parents=True)
    mask_path.parent.mkdir(parents=True)
    image_path.touch()
    mask_path.touch()

    df = pd.DataFrame(
        {
            "window_b": ["mappingafrica-256/images/a.tif"],
            "mask": ["mappingafrica-256/labels/a.tif"],
            "split": ["train"],
            "fld_prop": [0.2],
            "nonfld_prop": [0.8],
            "null_prop": [0.0],
            "country": ["AO"],
        }
    )
    catalog_path = tmp_path / "catalog.csv"
    df.to_csv(catalog_path, index=False)

    dataset = PlanetCSVImageMaskDataset(catalog_path, data_root=data_root, split="train")
    assert len(dataset) == 1
    assert dataset.resolve_path("mappingafrica-256/images/a.tif") == image_path

    results = check_paths_exist(df, data_root=data_root)
    assert results["valid_image_paths"] == 1
    assert results["valid_mask_paths"] == 1


def test_load_image_mask_pair_reads_rasters(tmp_path):
    image_path = tmp_path / "image.tif"
    mask_path = tmp_path / "mask.tif"
    transform = from_origin(0, 2, 1, 1)

    with rasterio.open(
        image_path,
        "w",
        driver="GTiff",
        height=2,
        width=2,
        count=4,
        dtype="float32",
        transform=transform,
    ) as dst:
        dst.write(torch.ones((4, 2, 2), dtype=torch.float32).numpy())

    with rasterio.open(
        mask_path,
        "w",
        driver="GTiff",
        height=2,
        width=2,
        count=1,
        dtype="uint8",
        transform=transform,
    ) as dst:
        dst.write(torch.tensor([[0, 1], [2, 0]], dtype=torch.uint8).numpy(), 1)

    image, mask = load_image_mask_pair(image_path, mask_path)
    assert image.shape == (4, 2, 2)
    assert mask.shape == (2, 2)
    assert image.dtype == torch.float32
    assert mask.dtype == torch.int64
