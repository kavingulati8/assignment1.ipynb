"""Starter smoke tests for Assignment 2 model shapes."""

import torch

from eo_models.cnn import SmallEOClassifier
from eo_models.unet import SmallUNet


def test_classifier_output_shape_after_implementation():
    model = SmallEOClassifier(in_channels=13, num_classes=10)
    x = torch.zeros((2, 13, 64, 64), dtype=torch.float32)
    y = model(x)
    assert y.shape == (2, 10)


def test_unet_output_shape_after_implementation():
    model = SmallUNet(in_channels=4, out_channels=1)
    x = torch.zeros((2, 4, 64, 64), dtype=torch.float32)
    y = model(x)
    assert y.shape[-2:] == x.shape[-2:]
    assert y.shape[0] == 2
    assert y.shape[1] == 1
