"""Starter smoke tests for Assignment 3 inference helpers."""

import torch

from eo_train.inference import predict_classification_batch, predict_segmentation_batch


class DummyClassifier(torch.nn.Module):
    def forward(self, x):
        return torch.zeros((x.shape[0], 10), device=x.device)


class DummySegmenter(torch.nn.Module):
    def forward(self, x):
        return torch.zeros((x.shape[0], 1, x.shape[-2], x.shape[-1]), device=x.device)


def test_predict_classification_batch_after_implementation():
    preds, logits = predict_classification_batch(DummyClassifier(), torch.zeros((2, 13, 64, 64)), torch.device("cpu"))
    assert logits.shape == (2, 10)
    assert preds.shape == (2,)


def test_predict_segmentation_batch_after_implementation():
    preds, probs, logits = predict_segmentation_batch(DummySegmenter(), torch.zeros((2, 4, 64, 64)), torch.device("cpu"))
    assert logits.shape == (2, 1, 64, 64)
    assert probs.min() >= 0 and probs.max() <= 1
    assert set(torch.unique(preds).tolist()).issubset({0, 1, False, True})
