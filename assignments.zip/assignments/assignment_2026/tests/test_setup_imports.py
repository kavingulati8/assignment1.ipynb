"""Verify that the assignment package and key dependencies import."""


def test_assignment_imports():
    import eo_dataloader  # noqa: F401
    import eo_models  # noqa: F401
    import eo_train  # noqa: F401
    import rasterio  # noqa: F401
    import torch  # noqa: F401
    import torchgeo  # noqa: F401
