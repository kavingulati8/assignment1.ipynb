"""Loss helpers for classification and segmentation."""

from __future__ import annotations

from torch import nn


def get_classification_loss():
    """Return a loss function for multi-class classification."""
    return nn.CrossEntropyLoss()


def get_segmentation_loss():
    """Return a loss function for binary segmentation logits and masks."""
    return nn.BCEWithLogitsLoss()
