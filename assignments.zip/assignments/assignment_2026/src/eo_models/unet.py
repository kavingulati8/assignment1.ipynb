"""Small U-Net baseline for Assignment 2."""

from __future__ import annotations

import torch
from torch import nn


class DoubleConv(nn.Module):
    """Two convolution layers used in a small U-Net block."""

    def __init__(self, in_channels: int, out_channels: int) -> None:
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.block(x)


class SmallUNet(nn.Module):
    """Small U-Net style segmentation model.

    The default returns one binary logit map with the same spatial size as the
    input. For multi-class masks, change `out_channels` and the loss function.
    """

    def __init__(self, in_channels: int, out_channels: int = 1, base_channels: int = 16) -> None:
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels

        self.enc1 = DoubleConv(in_channels, base_channels)
        self.pool1 = nn.MaxPool2d(2)
        self.enc2 = DoubleConv(base_channels, base_channels * 2)
        self.pool2 = nn.MaxPool2d(2)
        self.bottleneck = DoubleConv(base_channels * 2, base_channels * 4)

        self.up2 = nn.ConvTranspose2d(base_channels * 4, base_channels * 2, kernel_size=2, stride=2)
        self.dec2 = DoubleConv(base_channels * 4, base_channels * 2)
        self.up1 = nn.ConvTranspose2d(base_channels * 2, base_channels, kernel_size=2, stride=2)
        self.dec1 = DoubleConv(base_channels * 2, base_channels)
        self.final_conv = nn.Conv2d(base_channels, out_channels, kernel_size=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        enc1 = self.enc1(x)
        enc2 = self.enc2(self.pool1(enc1))
        bottleneck = self.bottleneck(self.pool2(enc2))

        dec2 = self.up2(bottleneck)
        dec2 = _crop_or_pad_like(dec2, enc2)
        dec2 = self.dec2(torch.cat([dec2, enc2], dim=1))
        dec1 = self.up1(dec2)
        dec1 = _crop_or_pad_like(dec1, enc1)
        dec1 = self.dec1(torch.cat([dec1, enc1], dim=1))
        return self.final_conv(dec1)


def _crop_or_pad_like(x: torch.Tensor, reference: torch.Tensor) -> torch.Tensor:
    """Match spatial shape to a skip connection tensor."""
    diff_y = reference.shape[-2] - x.shape[-2]
    diff_x = reference.shape[-1] - x.shape[-1]
    if diff_y == 0 and diff_x == 0:
        return x
    if diff_y < 0 or diff_x < 0:
        return x[..., : reference.shape[-2], : reference.shape[-1]]
    return nn.functional.pad(x, [diff_x // 2, diff_x - diff_x // 2, diff_y // 2, diff_y - diff_y // 2])
