"""eo_models package for IDLEO assignments."""
