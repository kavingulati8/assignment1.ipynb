"""Small CNN classifier baseline for Assignment 2."""

from __future__ import annotations

import torch
from torch import nn


class SmallEOClassifier(nn.Module):
    """Small CNN for EuroSAT100 classification.

    This baseline is intentionally compact so it trains quickly in Colab. You
    can modify channel widths, pooling, or the classifier head after verifying
    the default tensor shapes.
    """

    def __init__(self, in_channels: int, num_classes: int, hidden_channels: int = 32) -> None:
        super().__init__()
        self.in_channels = in_channels
        self.num_classes = num_classes

        self.features = nn.Sequential(
            nn.Conv2d(in_channels, hidden_channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(hidden_channels),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
            nn.Conv2d(hidden_channels, hidden_channels * 2, kernel_size=3, padding=1),
            nn.BatchNorm2d(hidden_channels * 2),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2),
            nn.Conv2d(hidden_channels * 2, hidden_channels * 4, kernel_size=3, padding=1),
            nn.BatchNorm2d(hidden_channels * 4),
            nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d(1),
        )
        self.classifier = nn.Linear(hidden_channels * 4, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        features = self.features(x)
        features = torch.flatten(features, start_dim=1)
        return self.classifier(features)
