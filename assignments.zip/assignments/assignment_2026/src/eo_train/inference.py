"""Inference helpers for Assignment 3."""

from __future__ import annotations

import torch


def predict_classification_batch(model, images, device):
    """Return predicted classes and logits for one classification batch."""
    model.eval()
    images = images.to(device).float()
    with torch.no_grad():
        logits = model(images)
        preds = torch.argmax(logits, dim=1)
    return preds.detach().cpu(), logits.detach().cpu()


def predict_segmentation_batch(model, images, device, threshold: float = 0.5):
    """Return binary predictions, probabilities, and logits for one segmentation batch."""
    model.eval()
    images = images.to(device).float()
    with torch.no_grad():
        logits = model(images)
        probabilities = torch.sigmoid(logits)
        preds = probabilities >= threshold
    return preds.detach().cpu(), probabilities.detach().cpu(), logits.detach().cpu()


def run_assignment_3_inference_checks(classifier_model=None, segmentation_model=None, classification_batch=None, segmentation_batch=None, device=None):
    """Return deterministic inference check results.

    Use this after loading models and preparing one batch from each workflow.
    """
    if device is None:
        device = torch.device("cpu")
    results = {}
    if classifier_model is not None and classification_batch is not None:
        images = classification_batch["image"] if isinstance(classification_batch, dict) else classification_batch[0]
        preds, logits = predict_classification_batch(classifier_model, images, device)
        results["classification_logits_shape"] = tuple(logits.shape)
        results["classification_preds_shape"] = tuple(preds.shape)
    if segmentation_model is not None and segmentation_batch is not None:
        images = segmentation_batch[0]
        preds, probabilities, logits = predict_segmentation_batch(segmentation_model, images, device)
        results["segmentation_logits_shape"] = tuple(logits.shape)
        results["segmentation_probability_min"] = float(probabilities.min().item())
        results["segmentation_probability_max"] = float(probabilities.max().item())
        results["segmentation_prediction_values"] = [int(x) for x in torch.unique(preds).tolist()]
    return results
