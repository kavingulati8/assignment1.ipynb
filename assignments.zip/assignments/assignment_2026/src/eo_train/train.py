"""Training and validation loops for Assignment 2."""

from __future__ import annotations

import torch


def _classification_batch(batch):
    if isinstance(batch, dict):
        return batch["image"], batch["label"]
    return batch[0], batch[1]


def _segmentation_batch(batch):
    return batch[0], batch[1]


def _prepare_binary_masks(masks: torch.Tensor) -> torch.Tensor:
    """Convert label masks to binary foreground masks for the baseline U-Net."""
    masks = masks.float()
    if masks.ndim == 3:
        masks = masks.unsqueeze(1)
    return (masks > 0).float()


def train_classification_one_epoch(model, dataloader, optimizer, loss_fn, device):
    """Train classifier for one epoch."""
    model.train()
    total_loss = 0.0
    total_correct = 0
    total_items = 0
    for batch in dataloader:
        images, labels = _classification_batch(batch)
        images = images.to(device).float()
        labels = labels.to(device).long()

        optimizer.zero_grad(set_to_none=True)
        logits = model(images)
        loss = loss_fn(logits, labels)
        loss.backward()
        optimizer.step()

        batch_size = labels.shape[0]
        total_loss += float(loss.item()) * batch_size
        total_correct += int((torch.argmax(logits, dim=1) == labels).sum().item())
        total_items += batch_size
    return {"loss": total_loss / max(total_items, 1), "accuracy": total_correct / max(total_items, 1)}


def validate_classification_one_epoch(model, dataloader, loss_fn, device):
    """Validate classifier for one epoch."""
    model.eval()
    total_loss = 0.0
    total_correct = 0
    total_items = 0
    with torch.no_grad():
        for batch in dataloader:
            images, labels = _classification_batch(batch)
            images = images.to(device).float()
            labels = labels.to(device).long()
            logits = model(images)
            loss = loss_fn(logits, labels)

            batch_size = labels.shape[0]
            total_loss += float(loss.item()) * batch_size
            total_correct += int((torch.argmax(logits, dim=1) == labels).sum().item())
            total_items += batch_size
    return {"loss": total_loss / max(total_items, 1), "accuracy": total_correct / max(total_items, 1)}


def train_segmentation_one_epoch(model, dataloader, optimizer, loss_fn, device):
    """Train segmentation model for one epoch."""
    model.train()
    total_loss = 0.0
    total_items = 0
    for batch in dataloader:
        images, masks = _segmentation_batch(batch)
        images = images.to(device).float()
        masks = _prepare_binary_masks(masks.to(device))

        optimizer.zero_grad(set_to_none=True)
        logits = model(images)
        loss = loss_fn(logits, masks)
        loss.backward()
        optimizer.step()

        batch_size = images.shape[0]
        total_loss += float(loss.item()) * batch_size
        total_items += batch_size
    return {"loss": total_loss / max(total_items, 1)}


def validate_segmentation_one_epoch(model, dataloader, loss_fn, device):
    """Validate segmentation model for one epoch."""
    model.eval()
    total_loss = 0.0
    total_items = 0
    with torch.no_grad():
        for batch in dataloader:
            images, masks = _segmentation_batch(batch)
            images = images.to(device).float()
            masks = _prepare_binary_masks(masks.to(device))
            logits = model(images)
            loss = loss_fn(logits, masks)

            batch_size = images.shape[0]
            total_loss += float(loss.item()) * batch_size
            total_items += batch_size
    return {"loss": total_loss / max(total_items, 1)}
