"""Metrics for classification and segmentation."""

from __future__ import annotations

import torch


def accuracy_from_logits(logits: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
    """Compute classification accuracy from logits and integer labels."""
    preds = torch.argmax(logits, dim=1)
    return (preds == labels).float().mean()


def accuracy_from_predictions(preds: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
    """Compute accuracy from predicted class IDs and labels."""
    return (preds == labels).float().mean()


def segmentation_iou(preds: torch.Tensor, masks: torch.Tensor, eps: float = 1e-7) -> torch.Tensor:
    """Compute binary intersection over union."""
    preds = preds.bool()
    masks = masks.bool()
    intersection = (preds & masks).sum().float()
    union = (preds | masks).sum().float()
    return (intersection + eps) / (union + eps)


def segmentation_dice(preds: torch.Tensor, masks: torch.Tensor, eps: float = 1e-7) -> torch.Tensor:
    """Compute binary Dice score."""
    preds = preds.bool()
    masks = masks.bool()
    intersection = (preds & masks).sum().float()
    return (2 * intersection + eps) / (preds.sum().float() + masks.sum().float() + eps)


def confusion_matrix_from_predictions(preds: torch.Tensor, labels: torch.Tensor, num_classes: int) -> torch.Tensor:
    """Return a simple confusion matrix."""
    matrix = torch.zeros((num_classes, num_classes), dtype=torch.long)
    for true_label, pred_label in zip(labels.view(-1), preds.view(-1)):
        matrix[int(true_label), int(pred_label)] += 1
    return matrix


def metric_is_bounded(value, low: float = 0.0, high: float = 1.0) -> bool:
    """Return True if a scalar metric is between low and high."""
    value = float(value)
    return low <= value <= high
