"""Evaluation helpers for Assignment 2 and 3."""

from __future__ import annotations


def summarize_history(history):
    """Return a small summary dictionary for a training history list or DataFrame."""
    if hasattr(history, "to_dict"):
        records = history.to_dict("records")
    else:
        records = list(history)
    if not records:
        return {"n_epochs": 0}

    summary = {"n_epochs": len(records)}
    for key in records[-1]:
        values = [row.get(key) for row in records if isinstance(row.get(key), (int, float))]
        if not values:
            continue
        summary[f"final_{key}"] = values[-1]
        summary[f"best_{key}"] = min(values) if "loss" in key else max(values)
    return summary
