"""Checkpoint helpers."""

from __future__ import annotations

from pathlib import Path

import torch


def save_checkpoint(model, path, extra=None):
    """Save a model state dict and optional metadata."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"model_state_dict": model.state_dict()}
    if extra is not None:
        payload["extra"] = extra
    torch.save(payload, path)
    return path


def load_checkpoint(path, model, device):
    """Load a model checkpoint into model and return the checkpoint payload."""
    path = Path(path)
    checkpoint = torch.load(path, map_location=device)
    model.load_state_dict(checkpoint["model_state_dict"])
    return checkpoint


def checkpoint_exists(path) -> bool:
    """Return whether a checkpoint path exists."""
    return Path(path).exists()
