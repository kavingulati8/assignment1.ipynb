"""eo_train package for IDLEO assignments."""
