"""General utility functions for the IDLEO assignments."""

from __future__ import annotations

import os
import random
from pathlib import Path

import numpy as np
import torch


def get_project_root() -> Path:
    """Return the project root by searching upward for README.md."""
    current = Path.cwd().resolve()
    for path in [current, *current.parents]:
        if (path / "README.md").exists() and (path / "src").exists():
            return path
    return current


def set_seed(seed: int = 42) -> None:
    """Set random seeds for reproducible examples."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def get_device() -> torch.device:
    """Return CUDA device when available, otherwise CPU."""
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def ensure_dir(path: str | Path) -> Path:
    """Create a directory if needed and return it as a Path."""
    path = Path(path)
    path.mkdir(parents=True, exist_ok=True)
    return path
