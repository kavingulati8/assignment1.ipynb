"""Deterministic checks for dataloaders and assignment verification."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd
import torch


def _resolve_catalog_path(value: str | Path, data_root: str | Path | None = None) -> Path:
    """Resolve a catalog path against a data root unless already absolute."""
    path = Path(value)
    if path.is_absolute() or data_root is None:
        return path
    return Path(data_root) / path


def check_catalog_schema(
    df: pd.DataFrame,
    required_columns: tuple[str, ...] = ("window_b", "mask", "split", "fld_prop", "nonfld_prop", "null_prop", "country"),
) -> dict[str, Any]:
    """Return deterministic checks for the provided Planet catalog schema."""
    missing = [col for col in required_columns if col not in df.columns]
    return {
        "n_rows": int(len(df)),
        "required_columns_present": len(missing) == 0,
        "missing_columns": missing,
        "columns": list(df.columns),
    }


def summarize_catalog_splits(df: pd.DataFrame, split_col: str = "split") -> dict[str, Any]:
    """Return split counts from the provided catalog."""
    if split_col not in df.columns:
        return {"split_col_present": False, "split_counts": {}}
    counts = df[split_col].value_counts(dropna=False).sort_index()
    return {
        "split_col_present": True,
        "split_counts": {str(k): int(v) for k, v in counts.items()},
    }


def check_paths_exist(
    df: pd.DataFrame,
    image_col: str = "window_b",
    mask_col: str = "mask",
    data_root: str | Path | None = None,
) -> dict[str, Any]:
    """Return deterministic path validity counts for catalog image/mask paths."""
    image_paths = df[image_col].apply(lambda p: _resolve_catalog_path(p, data_root))
    mask_paths = df[mask_col].apply(lambda p: _resolve_catalog_path(p, data_root))
    image_paths_exist = image_paths.apply(lambda p: p.exists())
    mask_paths_exist = mask_paths.apply(lambda p: p.exists())
    return {
        "n_rows": int(len(df)),
        "valid_image_paths": int(image_paths_exist.sum()),
        "valid_mask_paths": int(mask_paths_exist.sum()),
        "missing_image_paths": int((~image_paths_exist).sum()),
        "missing_mask_paths": int((~mask_paths_exist).sum()),
        "first_image_path": str(image_paths.iloc[0]) if len(image_paths) else None,
        "first_mask_path": str(mask_paths.iloc[0]) if len(mask_paths) else None,
    }


def summarize_balance_columns(
    df: pd.DataFrame,
    columns: tuple[str, ...] = ("fld_prop", "nonfld_prop", "null_prop"),
) -> dict[str, Any]:
    """Summarize class-balance columns included in the Planet catalog."""
    results: dict[str, Any] = {}
    for col in columns:
        if col not in df.columns:
            results[f"{col}_present"] = False
            continue
        values = pd.to_numeric(df[col], errors="coerce")
        results[f"{col}_present"] = True
        results[f"{col}_min"] = float(values.min())
        results[f"{col}_max"] = float(values.max())
        results[f"{col}_mean"] = float(values.mean())
    return results


def inspect_classification_batch(images: torch.Tensor, labels: torch.Tensor) -> dict[str, Any]:
    """Return standard classification batch diagnostics."""
    return {
        "image_shape": tuple(images.shape),
        "label_shape": tuple(labels.shape),
        "image_dtype": str(images.dtype),
        "label_dtype": str(labels.dtype),
        "image_is_finite": bool(torch.isfinite(images).all().item()),
        "label_min": int(labels.min().item()) if labels.numel() else None,
        "label_max": int(labels.max().item()) if labels.numel() else None,
        "unique_labels": [int(x) for x in torch.unique(labels).cpu().tolist()],
    }


def inspect_image_mask_batch(images: torch.Tensor, masks: torch.Tensor) -> dict[str, Any]:
    """Return standard segmentation batch diagnostics."""
    return {
        "image_shape": tuple(images.shape),
        "mask_shape": tuple(masks.shape),
        "image_dtype": str(images.dtype),
        "mask_dtype": str(masks.dtype),
        "image_is_finite": bool(torch.isfinite(images).all().item()),
        "mask_unique_values": [float(x) for x in torch.unique(masks).cpu().tolist()[:20]],
        "spatial_shapes_match": tuple(images.shape[-2:]) == tuple(masks.shape[-2:]),
    }


def run_assignment_1_checks(eurosat_loader=None, planet_dataset=None, planet_loader=None) -> dict[str, Any]:
    """Run deterministic Assignment 1 checks.

    This function should produce the same keys for all students.
    Values may vary when batch size varies, but pass flags should be stable.
    """
    results: dict[str, Any] = {}

    if eurosat_loader is not None:
        batch = next(iter(eurosat_loader))
        images = batch["image"] if isinstance(batch, dict) else batch[0]
        labels = batch["label"] if isinstance(batch, dict) else batch[1]
        diag = inspect_classification_batch(images, labels)
        results.update({f"eurosat_{k}": v for k, v in diag.items()})
        results["eurosat_image_ndim_is_4"] = len(images.shape) == 4
        results["eurosat_has_13_channels"] = images.shape[1] == 13
        results["eurosat_labels_are_1d"] = len(labels.shape) == 1
        results["eurosat_labels_in_expected_range"] = int(labels.min()) >= 0 and int(labels.max()) < 10

    if planet_dataset is not None:
        results["planet_dataset_length"] = len(planet_dataset)
        results["planet_dataset_nonempty"] = len(planet_dataset) > 0
        if hasattr(planet_dataset, "df"):
            results.update({f"planet_catalog_{k}": v for k, v in check_catalog_schema(planet_dataset.df).items()})
            results.update({f"planet_catalog_{k}": v for k, v in summarize_catalog_splits(planet_dataset.df).items()})
            results.update({f"planet_balance_{k}": v for k, v in summarize_balance_columns(planet_dataset.df).items()})

    if planet_loader is not None:
        batch = next(iter(planet_loader))
        images, masks = batch[0], batch[1]
        diag = inspect_image_mask_batch(images, masks)
        results.update({f"planet_{k}": v for k, v in diag.items()})
        results["planet_image_ndim_is_4"] = len(images.shape) == 4
        results["planet_mask_ndim_is_3_or_4"] = len(masks.shape) in (3, 4)

    return results
