"""eo_dataloader package for IDLEO assignments."""
