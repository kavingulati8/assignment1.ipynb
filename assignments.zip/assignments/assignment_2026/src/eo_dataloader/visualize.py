"""Visualization helpers for EO datasets and predictions."""

from __future__ import annotations

import matplotlib.pyplot as plt
import torch


def _to_cpu_tensor(x):
    if isinstance(x, torch.Tensor):
        return x.detach().cpu()
    return torch.as_tensor(x)


def make_rgb_array(image: torch.Tensor, rgb_bands: tuple[int, int, int] = (3, 2, 1)):
    """Convert a channel-first tensor to a displayable RGB array.

    Default bands assume Sentinel-2 style band order in TorchGeo EuroSAT.
    Students may need to adjust bands for Planet imagery.
    """
    image = _to_cpu_tensor(image)
    rgb = image[list(rgb_bands), :, :].permute(1, 2, 0).float()
    rgb_min = torch.quantile(rgb, 0.02)
    rgb_max = torch.quantile(rgb, 0.98)
    rgb = torch.clamp((rgb - rgb_min) / (rgb_max - rgb_min + 1e-8), 0, 1)
    return rgb.numpy()


def show_rgb_image(image: torch.Tensor, rgb_bands: tuple[int, int, int] = (3, 2, 1), title: str = "rgb image") -> None:
    plt.figure(figsize=(5, 5))
    plt.imshow(make_rgb_array(image, rgb_bands=rgb_bands))
    plt.title(title)
    plt.axis("off")
    plt.show()


def show_mask(mask: torch.Tensor, title: str = "mask") -> None:
    mask = _to_cpu_tensor(mask).squeeze().numpy()
    plt.figure(figsize=(5, 5))
    plt.imshow(mask)
    plt.title(title)
    plt.axis("off")
    plt.show()


def show_rgb_and_mask(image: torch.Tensor, mask: torch.Tensor, rgb_bands: tuple[int, int, int] = (3, 2, 1)) -> None:
    fig, axes = plt.subplots(1, 2, figsize=(10, 5))
    axes[0].imshow(make_rgb_array(image, rgb_bands=rgb_bands))
    axes[0].set_title("rgb image")
    axes[0].axis("off")
    axes[1].imshow(_to_cpu_tensor(mask).squeeze().numpy())
    axes[1].set_title("mask")
    axes[1].axis("off")
    plt.show()


def show_eurosat_samples(batch, class_names=None, max_samples: int = 6) -> None:
    """Show a small grid of EuroSAT samples."""
    images = batch["image"] if isinstance(batch, dict) else batch[0]
    labels = batch["label"] if isinstance(batch, dict) else batch[1]
    n = min(max_samples, images.shape[0])
    fig, axes = plt.subplots(1, n, figsize=(3 * n, 3))
    if n == 1:
        axes = [axes]
    for i in range(n):
        axes[i].imshow(make_rgb_array(images[i]))
        label = int(labels[i])
        title = class_names[label] if class_names is not None else f"class {label}"
        axes[i].set_title(title)
        axes[i].axis("off")
    plt.show()


def show_segmentation_prediction(image, mask, probability, prediction, rgb_bands=(2, 1, 0)) -> None:
    """Show image, ground truth, probability, and predicted mask."""
    fig, axes = plt.subplots(1, 4, figsize=(16, 4))
    axes[0].imshow(make_rgb_array(image, rgb_bands=rgb_bands))
    axes[0].set_title("rgb image")
    axes[1].imshow(_to_cpu_tensor(mask).squeeze().numpy())
    axes[1].set_title("ground truth")
    axes[2].imshow(_to_cpu_tensor(probability).squeeze().numpy(), vmin=0, vmax=1)
    axes[2].set_title("probability")
    axes[3].imshow(_to_cpu_tensor(prediction).squeeze().numpy(), vmin=0, vmax=1)
    axes[3].set_title("prediction")
    for ax in axes:
        ax.axis("off")
    plt.show()
