"""Dataset classes and dataset helpers."""

from __future__ import annotations

from pathlib import Path
from typing import Callable, Optional

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset

try:
    import rasterio
except ImportError:  # pragma: no cover
    rasterio = None


class PlanetCSVImageMaskDataset(Dataset):
    """Load image and mask pairs from a CSV catalog.

    The course catalog uses `window_b` for image chips, `mask` for label chips,
    and `split` for train/validate/test separation.
    """

    def __init__(
        self,
        csv_path: str | Path,
        data_root: str | Path,
        image_col: str = "window_b",
        mask_col: str = "mask",
        split: str | None = None,
        split_col: str = "split",
        max_items: int | None = None,
        transform: Optional[Callable] = None,
        return_metadata: bool = True,
    ) -> None:
        self.csv_path = Path(csv_path)
        self.data_root = Path(data_root)
        self.image_col = image_col
        self.mask_col = mask_col
        self.split = split
        self.split_col = split_col
        self.max_items = max_items
        self.transform = transform
        self.return_metadata = return_metadata

        self.df = pd.read_csv(self.csv_path)
        required_cols = {self.image_col, self.mask_col}
        if self.split is not None:
            required_cols.add(self.split_col)
        missing = sorted(required_cols - set(self.df.columns))
        if missing:
            raise ValueError(f"Catalog is missing required columns: {missing}")

        if self.split is not None:
            self.df = self.df[self.df[self.split_col] == self.split].reset_index(drop=True)
        if self.max_items is not None:
            self.df = self.df.head(self.max_items).reset_index(drop=True)

    def __len__(self) -> int:
        return len(self.df)

    def resolve_path(self, value: str | Path) -> Path:
        """Resolve a catalog path against `data_root` unless already absolute."""
        path = Path(value)
        if path.is_absolute():
            return path
        return self.data_root / path

    def __getitem__(self, idx: int):
        row = self.df.iloc[idx]
        image_path = self.resolve_path(row[self.image_col])
        mask_path = self.resolve_path(row[self.mask_col])
        image, mask = load_image_mask_pair(image_path, mask_path)

        if self.transform is not None:
            transformed = self.transform(image, mask)
            if isinstance(transformed, tuple) and len(transformed) == 2:
                image, mask = transformed
            else:
                raise TypeError("Planet transforms must return an (image, mask) tuple.")

        if not self.return_metadata:
            return image, mask

        metadata = row.to_dict()
        metadata["image_path"] = str(image_path)
        metadata["mask_path"] = str(mask_path)
        return image, mask, metadata


class PlanetDirectoryImageMaskDataset(Dataset):
    """Load image and mask pairs from matched folder paths."""

    def __init__(self, pairs: list[tuple[Path, Path]], transform: Optional[Callable] = None):
        self.pairs = pairs
        self.transform = transform

    def __len__(self) -> int:
        return len(self.pairs)

    def __getitem__(self, idx: int):
        image_path, mask_path = self.pairs[idx]
        image, mask = load_image_mask_pair(image_path, mask_path)
        if self.transform is not None:
            transformed = self.transform(image, mask)
            if isinstance(transformed, tuple) and len(transformed) == 2:
                image, mask = transformed
            else:
                raise TypeError("Planet transforms must return an (image, mask) tuple.")
        return image, mask, {"image_path": str(image_path), "mask_path": str(mask_path)}


def load_image_mask_pair(image_path: str | Path, mask_path: str | Path) -> tuple[torch.Tensor, torch.Tensor]:
    """Read one raster image chip and mask as tensors.

    Images are returned as float32 channel-first tensors. Masks are returned as
    int64 spatial tensors. The helper is intentionally small so students can
    inspect and critique every step.
    """
    if rasterio is None:  # pragma: no cover
        raise ImportError("rasterio is required to read Planet raster chips.")

    image_path = Path(image_path)
    mask_path = Path(mask_path)
    if not image_path.exists():
        raise FileNotFoundError(f"Image file not found: {image_path}")
    if not mask_path.exists():
        raise FileNotFoundError(f"Mask file not found: {mask_path}")

    with rasterio.open(image_path) as src:
        image_array = src.read()
    with rasterio.open(mask_path) as src:
        mask_array = src.read(1)

    image_array = np.nan_to_num(image_array).astype("float32", copy=False)
    mask_array = mask_array.astype("int64", copy=False)

    image = torch.from_numpy(np.ascontiguousarray(image_array))
    mask = torch.from_numpy(np.ascontiguousarray(mask_array))
    if image.shape[-2:] != mask.shape[-2:]:
        raise ValueError(f"Image and mask spatial shapes differ: {tuple(image.shape[-2:])} vs {tuple(mask.shape[-2:])}")
    return image, mask


def match_image_mask_files(
    image_dir: str | Path,
    mask_dir: str | Path,
    image_suffix: str = ".tif",
    mask_suffix: str = ".tif",
) -> tuple[list[tuple[Path, Path]], list[Path], list[Path]]:
    """Match image and mask files by filename stem.

    Returns matched pairs, images without masks, and masks without images.
    """
    image_dir = Path(image_dir)
    mask_dir = Path(mask_dir)

    image_files = sorted(image_dir.glob(f"*{image_suffix}"))
    mask_files = sorted(mask_dir.glob(f"*{mask_suffix}"))

    image_by_stem = {p.stem: p for p in image_files}
    mask_by_stem = {p.stem: p for p in mask_files}

    shared_stems = sorted(set(image_by_stem) & set(mask_by_stem))
    pairs = [(image_by_stem[stem], mask_by_stem[stem]) for stem in shared_stems]

    images_without_masks = [image_by_stem[s] for s in sorted(set(image_by_stem) - set(mask_by_stem))]
    masks_without_images = [mask_by_stem[s] for s in sorted(set(mask_by_stem) - set(image_by_stem))]

    return pairs, images_without_masks, masks_without_images
